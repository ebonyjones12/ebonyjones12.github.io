package com.example.focus;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * WeightDataActivity is the main screen of the Focus app.
 * It displays weight entries in a grid and allows users to:
 * - Add new weight entries (Create)
 * - View all entries in a scrollable grid (Read)
 * - Edit existing entries (Update)
 * - Delete entries (Delete)
 * - Enable SMS notifications for reaching goal weight
 */
public class WeightDataActivity extends AppCompatActivity {

    // UI elements
    private EditText etDate;
    private EditText etWeight;
    private Button btnAdd;
    private Button btnRequestSMS;
    private Button btnSortDate;
    private Button btnSortWeight;
    private LinearLayout dataContainer;

    // Database helper
    private DatabaseHelper databaseHelper;

    // Current logged-in user ID
    private int currentUserId;

    // SMS permission request code
    private static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_data);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Get the current user ID from login session
        currentUserId = LoginActivity.getUserId(this);

        // Connect UI elements to their XML counterparts
        etDate = findViewById(R.id.etDate);
        etWeight = findViewById(R.id.etWeight);
        btnAdd = findViewById(R.id.btnAdd);
        btnRequestSMS = findViewById(R.id.btnRequestSMS);
        btnSortDate = new Button(this);
        btnSortWeight = new Button(this);
        dataContainer = findViewById(R.id.dataContainer);

        // Set up Add button click listener
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightEntry();
            }
        });

        // Set up SMS permission button click listener
        btnRequestSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSMSPermission();
            }
        });

        // Load and display existing weight entries
        // Set up sort by date button
        btnSortDate.setText("Sort by Date");
        btnSortDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadSortedByDate();
            }
        });

// Set up sort by weight button
        btnSortWeight.setText("Sort by Weight");
        btnSortWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadSortedByWeight();
            }
        });

        dataContainer.addView(btnSortDate);
        dataContainer.addView(btnSortWeight);
        refreshWeightGrid();

        // Update SMS button text based on current permission status
        updateSMSButtonText();
    }

    /**
     * Adds a new weight entry to the database.
     * Validates input before saving.
     */
    private void addWeightEntry() {
        // Get user input
        String date = etDate.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();

        // Validate that fields are not empty
        if (date.isEmpty() || weightStr.isEmpty()) {
            Toast.makeText(this, "Please enter both date and weight",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse weight value
        double weight;
        try {
            weight = Double.parseDouble(weightStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid weight",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Add entry to database
        boolean success = databaseHelper.addWeightEntry(currentUserId, date, weight);

        if (success) {
            Toast.makeText(this, "Weight entry added!", Toast.LENGTH_SHORT).show();

            // Clear input fields
            etDate.setText("");
            etWeight.setText("");

            // Refresh the grid to show new entry
            refreshWeightGrid();

            // Check if user reached their goal weight
            checkGoalWeight(weight);
        } else {
            Toast.makeText(this, "Error adding entry", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Refreshes the weight grid by clearing it and reloading all entries from database.
     * This is the READ operation - displays all data in the grid.
     */
    private void refreshWeightGrid() {
        // Clear existing rows from the container
        dataContainer.removeAllViews();

        // Get all weight entries for current user from database
        Cursor cursor = databaseHelper.getAllWeightEntries(currentUserId);

        // Loop through each entry and create a row for it
        while (cursor.moveToNext()) {
            // Get data from cursor
            int weightId = cursor.getInt(0);
            String date = cursor.getString(1);
            double weight = cursor.getDouble(2);

            // Create a row for this entry
            createWeightRow(weightId, date, weight);
        }

        cursor.close();
    }

    /**
     * Creates a single row in the weight grid.
     * Each row displays date, weight, and action buttons for edit and delete.
     */
    private void createWeightRow(final int weightId, final String date, final double weight) {
        // Create the row container
        LinearLayout row = new LinearLayout(this);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundColor(Color.WHITE);
        row.setPadding(24, 24, 24, 24);

        // Create date TextView
        TextView tvDate = new TextView(this);
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f);
        tvDate.setLayoutParams(dateParams);
        tvDate.setText(date);
        tvDate.setTextSize(14);

        // Create weight TextView
        TextView tvWeight = new TextView(this);
        LinearLayout.LayoutParams weightParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tvWeight.setLayoutParams(weightParams);
        tvWeight.setText(String.valueOf(weight));
        tvWeight.setTextSize(14);

        // Create Edit button
        Button btnEdit = new Button(this);
        LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f);
        editParams.setMarginEnd(8);
        btnEdit.setLayoutParams(editParams);
        btnEdit.setText("Edit");
        btnEdit.setTextSize(11);
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDialog(weightId, date, weight);
            }
        });

        // Create Delete button
        Button btnDelete = new Button(this);
        LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f);
        btnDelete.setLayoutParams(deleteParams);
        btnDelete.setText("Delete");
        btnDelete.setTextSize(11);
        btnDelete.setBackgroundColor(Color.parseColor("#F44336"));
        btnDelete.setTextColor(Color.WHITE);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteConfirmation(weightId);
            }
        });

        // Add all views to the row
        row.addView(tvDate);
        row.addView(tvWeight);
        row.addView(btnEdit);
        row.addView(btnDelete);

        // Add a small margin at bottom for spacing between rows
        LinearLayout.LayoutParams rowParams = (LinearLayout.LayoutParams) row.getLayoutParams();
        rowParams.setMargins(0, 0, 0, 4);
        row.setLayoutParams(rowParams);

        // Add the row to the container
        dataContainer.addView(row);
    }

    /**
     * Shows a dialog to edit an existing weight entry.
     * This is part of the UPDATE operation.
     */
    private void showEditDialog(final int weightId, String currentDate, double currentWeight) {
        // Create dialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight Entry");

        // Create layout for dialog
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        // Create date input field
        final EditText inputDate = new EditText(this);
        inputDate.setHint("Date (MM/DD/YYYY)");
        inputDate.setText(currentDate);
        layout.addView(inputDate);

        // Create weight input field
        final EditText inputWeight = new EditText(this);
        inputWeight.setHint("Weight (lbs)");
        inputWeight.setText(String.valueOf(currentWeight));
        inputWeight.setInputType(android.text.InputType.TYPE_CLASS_NUMBER |
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        layout.addView(inputWeight);

        builder.setView(layout);

        // Set up Save button
        builder.setPositiveButton("Save", (dialog, which) -> {
            String newDate = inputDate.getText().toString().trim();
            String newWeightStr = inputWeight.getText().toString().trim();

            if (!newDate.isEmpty() && !newWeightStr.isEmpty()) {
                try {
                    double newWeight = Double.parseDouble(newWeightStr);
                    boolean success = databaseHelper.updateWeightEntry(weightId, newDate, newWeight);

                    if (success) {
                        Toast.makeText(this, "Entry updated!", Toast.LENGTH_SHORT).show();
                        refreshWeightGrid();
                        checkGoalWeight(newWeight);
                    } else {
                        Toast.makeText(this, "Error updating entry", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Please enter a valid weight",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set up Cancel button
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    /**
     * Shows a confirmation dialog before deleting an entry.
     * This is the DELETE operation.
     */
    private void showDeleteConfirmation(final int weightId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Entry");
        builder.setMessage("Are you sure you want to delete this weight entry?");

        builder.setPositiveButton("Delete", (dialog, which) -> {
            boolean success = databaseHelper.deleteWeightEntry(weightId);

            if (success) {
                Toast.makeText(this, "Entry deleted!", Toast.LENGTH_SHORT).show();
                refreshWeightGrid();
            } else {
                Toast.makeText(this, "Error deleting entry", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // ==================== SMS NOTIFICATION METHODS ====================

    /**
     * Handles the SMS permission button click.
     * Either requests permission or shows goal weight setup if already granted.
     */
    private void handleSMSPermission() {
        // Check if SMS permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted - show goal weight setup
            showGoalWeightDialog();
        } else {
            // Request SMS permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    /**
     * Callback for permission request results.
     * Handles the user's response to the SMS permission request.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted - show goal weight setup
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
                showGoalWeightDialog();
                updateSMSButtonText();
            } else {
                // Permission denied - app continues to work without SMS feature
                Toast.makeText(this,
                        "SMS permission denied. You can still use the app without notifications.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Shows a dialog to set up goal weight and phone number for SMS notifications.
     */
    private void showGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Up Goal Notifications");

        // Create layout for dialog
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        // Create goal weight input
        final EditText inputGoal = new EditText(this);
        inputGoal.setHint("Goal Weight (lbs)");
        inputGoal.setInputType(android.text.InputType.TYPE_CLASS_NUMBER |
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        // Pre-fill with existing goal if set
        double existingGoal = databaseHelper.getGoalWeight(currentUserId);
        if (existingGoal > 0) {
            inputGoal.setText(String.valueOf(existingGoal));
        }
        layout.addView(inputGoal);

        // Create phone number input
        final EditText inputPhone = new EditText(this);
        inputPhone.setHint("Phone Number (for SMS)");
        inputPhone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);

        // Pre-fill with existing phone if set
        String existingPhone = databaseHelper.getPhoneNumber(currentUserId);
        if (existingPhone != null && !existingPhone.isEmpty()) {
            inputPhone.setText(existingPhone);
        }
        layout.addView(inputPhone);

        builder.setView(layout);

        // Set up Save button
        builder.setPositiveButton("Save", (dialog, which) -> {
            String goalStr = inputGoal.getText().toString().trim();
            String phone = inputPhone.getText().toString().trim();

            if (!goalStr.isEmpty() && !phone.isEmpty()) {
                try {
                    double goalWeight = Double.parseDouble(goalStr);
                    databaseHelper.updateGoalWeight(currentUserId, goalWeight);
                    databaseHelper.updatePhoneNumber(currentUserId, phone);
                    Toast.makeText(this,
                            "Goal set! You'll get a text when you reach " + goalWeight + " lbs.",
                            Toast.LENGTH_LONG).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Please enter a valid goal weight",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please fill in both fields",
                        Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    /**
     * Checks if the user has reached their goal weight and sends SMS if so.
     */
    private void checkGoalWeight(double currentWeight) {
        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return; // No permission, skip SMS check
        }

        // Get goal weight and phone number
        double goalWeight = databaseHelper.getGoalWeight(currentUserId);
        String phoneNumber = databaseHelper.getPhoneNumber(currentUserId);

        // Check if goal is set and phone number exists
        if (goalWeight <= 0 || phoneNumber == null || phoneNumber.isEmpty()) {
            return; // Goal not set up
        }

        // Check if current weight meets or beats goal (assuming goal is to lose weight)
        if (currentWeight <= goalWeight) {
            sendGoalReachedSMS(phoneNumber, currentWeight, goalWeight);
        }
    }

    /**
     * Sends an SMS notification when user reaches their goal weight.
     */
    private void sendGoalReachedSMS(String phoneNumber, double currentWeight, double goalWeight) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Congratulations! You've reached your goal weight of " +
                    goalWeight + " lbs! Your current weight is " + currentWeight + " lbs. " +
                    "Keep up the great work! - Focus App";

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "Goal reached! SMS notification sent!",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not send SMS: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Updates the SMS button text based on current permission and setup status.
     */
    private void updateSMSButtonText() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            double goalWeight = databaseHelper.getGoalWeight(currentUserId);
            if (goalWeight > 0) {
                btnRequestSMS.setText("Goal: " + goalWeight + " lbs (Tap to change)");
            } else {
                btnRequestSMS.setText("Set Goal Weight & Enable SMS");
            }
        } else {
            btnRequestSMS.setText("Enable Goal Notifications (SMS)");
        }
    }
    /**
     * Loads weight entries sorted by date descending.
     */
    private void loadSortedByDate() {
        dataContainer.removeAllViews();
        dataContainer.addView(btnSortDate);
        dataContainer.addView(btnSortWeight);

        Cursor cursor = databaseHelper.getWeightEntriesSortedByDate(currentUserId, "DESC");
        while (cursor.moveToNext()) {
            int weightId = cursor.getInt(0);
            String date = cursor.getString(1);
            double weight = cursor.getDouble(2);
            createWeightRow(weightId, date, weight);
        }
        cursor.close();
        Toast.makeText(this, "Sorted by date", Toast.LENGTH_SHORT).show();
    }

    /**
     * Loads weight entries sorted by weight value ascending.
     */
    private void loadSortedByWeight() {
        dataContainer.removeAllViews();
        dataContainer.addView(btnSortDate);
        dataContainer.addView(btnSortWeight);

        Cursor cursor = databaseHelper.getWeightEntriesSortedByWeight(currentUserId, "ASC");
        while (cursor.moveToNext()) {
            int weightId = cursor.getInt(0);
            String date = cursor.getString(1);
            double weight = cursor.getDouble(2);
            createWeightRow(weightId, date, weight);
        }
        cursor.close();
        Toast.makeText(this, "Sorted by weight", Toast.LENGTH_SHORT).show();
    }
}
