package com.example.focus;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity is the entry point of the Focus app.
 * It checks if a user is already logged in and redirects accordingly:
 * - If logged in: goes directly to weight tracking screen
 * - If not logged in: goes to login screen
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if user is already logged in
        int userId = LoginActivity.getUserId(this);

        if (userId != -1) {
            // User is logged in - go directly to weight tracking
            Intent intent = new Intent(this, WeightDataActivity.class);
            startActivity(intent);
        } else {
            // User is not logged in - go to login screen
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

        // Close MainActivity so it's not in the back stack
        finish();
    }
}